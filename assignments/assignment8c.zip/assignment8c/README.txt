This package uses HTMLParser to scrape your IP address from the internets
http://checkip.dyndns.org/
