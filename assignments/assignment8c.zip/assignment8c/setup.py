from setuptools import setup

setup(
    name="xhtmlpython",
    version="1.0",
    description="Prints your IP address to the console",
    author="Stephen Pawulski",
    author_email="spawulski@academic.rrc.ca",
    py_modules=["xhtmlpython"],
    )

