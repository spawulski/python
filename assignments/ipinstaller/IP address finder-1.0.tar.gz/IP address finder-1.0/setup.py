from setuptools import setup

setup(
    name="IP address finder",
    version="1.0",
    description="Prints your IP address to the console",
    author="Stephen Pawulski",
    author_email="spawulski@academic.rrc.ca",
    py_modules=["IPFinder"],
    )

