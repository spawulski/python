This package uses HTMLParser to scrape color and their hex values from:
http://www.colourhexa.com/color-names
